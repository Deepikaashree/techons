ds = datastore('feeds.csv');
ds.TreatAsMissing = 'NA';
tt  = tall(ds) % Tall table
Y = tt.Var1 > 1000 % Class labels
X = tt{:,1:end-1} % Predictor data
R = rmmissing([X Y]); % Data with missing entries removed
X = R(:,1:end-1); 
Y = R(:,end); 
Z = zscore(X);
rng('default') 
tallrng('default')
Mdl = fitckernel(Z,Y,'Verbose',0,'OptimizeHyperparameters','auto',...
    'HyperparameterOptimizationOptions',struct('AcquisitionFunctionName','expected-improvement-plus'))
rng('default') % For reproducibility
tallrng('default') % For reproducibility
Partition = cvpartition(Y,'Holdout',1/3);
trainingInds = training(Partition); % Indices for the training set
testInds = test(Partition);         % Indices for the test set
Ytrain = Y(trainingInds); % Training class labels
Xtrain = X(trainingInds,:);
[Ztrain,mu,stddev] = zscore(Xtrain); % Standardized training data

Ytest = Y(testInds); % Testing class labels
Xtest = X(testInds,:);
Ztest = (Xtest-mu)./stddev; % Standardized test data
N = gather(numel(Ytrain)); % Evaluate the length of the tall training array in memory
sigma = optimizableVariable('sigma',[1e-3,1e3],'Transform','log');
lambda = optimizableVariable('lambda',[(1e-3)/N, (1e3)/N],'Transform','log');
minfn = @(z)gather(loss(fitckernel(Ztrain,Ytrain, ...
    'KernelScale',z.sigma,'Lambda',z.lambda,'Verbose',0), ...
    Ztest,Ytest));
results = bayesopt(minfn,[sigma,lambda],'AcquisitionFunctionName','expected-improvement-plus')

zbest = bestPoint(results)